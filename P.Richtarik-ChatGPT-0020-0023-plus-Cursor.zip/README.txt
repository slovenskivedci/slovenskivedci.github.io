P. Richtarik — ChatGPT credits LHONW7ZI-0020–0023 + Cursor card charge
=====================================================================

Source of funds: Baseline (BRF BAS/1/1677-01-01)
Card: SNB Mastercard ending 4672

ChatGPT / Codex credits (Stripe invoices + receipts on hand):
LHONW7ZI-0020  22 Sep 2026  5,000 credits  $230.00  (~SAR 883.91 on card 21 Sep)
LHONW7ZI-0021  22 Sep 2026  1,000 credits   $46.00  (~SAR 176.78 on card 22 Sep)
LHONW7ZI-0022  22 Sep 2026  2,000 credits   $92.00  (~SAR 353.57 on card 22 Sep)
LHONW7ZI-0023  22 Sep 2026  2,500 credits  $115.00  (~SAR 441.96 on card 22 Sep)
TOTAL with PDFs                                  $483.00

Extra OpenAI on card (invoice PDF still needed):
OPENAI* CHATGPT CREDIT  22/09/2026  SAR 441.96  (~$115) — likely LHONW7ZI-0024+
(second identical SAR 441.96 line on the same printout; only one maps to 0023)

Cursor:
CURSOR USAGE AUG — SNB charge 21/09/2026 SAR 56.89
(Cursor invoice PDF still needed from cursor.com billing — not in email)

Card proof:
SNB-MyCards-redacted-OpenAI-x5-Cursor.png — personal rows (ZED, Tamimi) blacked;
keeps five OPENAI* CHATGPT CREDIT lines + one CURSOR USAGE AUG line.

DO NOT re-claim LHONW7ZI-0001–0019 (CFS 12678 / 12791).
