P. Richtarik — ChatGPT credits LHONW7ZI-0020–0024 + Cursor 0016–0017
=====================================================================

Source of funds: Baseline (BRF BAS/1/1677-01-01)
Card: SNB Mastercard ending 4672

ChatGPT / Codex credits (Stripe invoices + receipts):
LHONW7ZI-0020  22 Sep 2026  5,000 credits  $230.00  (~SAR 883.91)
LHONW7ZI-0021  22 Sep 2026  1,000 credits   $46.00  (~SAR 176.78)
LHONW7ZI-0022  22 Sep 2026  2,000 credits   $92.00  (~SAR 353.57)
LHONW7ZI-0023  22 Sep 2026  2,500 credits  $115.00  (~SAR 441.96)
LHONW7ZI-0024  22 Sep 2026  2,500 credits  $115.00  (~SAR 441.96)
TOTAL ChatGPT                                  $598.00

Cursor (new — not previously claimed):
5KAS85SU-0016  19 Sep 2026  Cursor Ultra Sep 19–Oct 19  $230.00  (~SAR 883; card printout still needed)
5KAS85SU-0017  21 Sep 2026  Cursor Usage (cycle from Aug 19)  $14.80  (= SAR 56.89 “USAGE AUG” on card)
TOTAL Cursor new                               $244.80

DO NOT include / re-claim:
5KAS85SU-0015 ($115.07) — already in CFS 12531 with 0010–0014
LHONW7ZI-0001–0019 — CFS 12678 / 12791
Cursor Ultra 0001 — CFS 12330; Cursor 0002–0009 — CFS 12454

Card proof on hand:
SNB-MyCards-redacted-OpenAI-x5-Cursor.png — five OPENAI lines + CURSOR USAGE AUG (0017).
Still need a redacted SNB printout showing the Ultra $230 / ~SAR 883 charge around 19 Sep.
