P. Richtarik — ChatGPT credits LHONW7ZI-0020–0024 + Cursor card charge
=====================================================================

Source of funds: Baseline (BRF BAS/1/1677-01-01)
Card: SNB Mastercard ending 4672

ChatGPT / Codex credits (Stripe invoices + receipts):
LHONW7ZI-0020  22 Sep 2026  5,000 credits  $230.00  (~SAR 883.91 on card 21 Sep)
LHONW7ZI-0021  22 Sep 2026  1,000 credits   $46.00  (~SAR 176.78 on card 22 Sep)
LHONW7ZI-0022  22 Sep 2026  2,000 credits   $92.00  (~SAR 353.57 on card 22 Sep)
LHONW7ZI-0023  22 Sep 2026  2,500 credits  $115.00  (~SAR 441.96 on card 22 Sep)
LHONW7ZI-0024  22 Sep 2026  2,500 credits  $115.00  (~SAR 441.96 on card 22 Sep; Mastercard 4672)
TOTAL ChatGPT                                  $598.00

Cursor:
CURSOR USAGE AUG — SNB charge 21/09/2026 SAR 56.89 (~$14–15)
(Cursor invoice PDF still needed from https://cursor.com/dashboard/billing — not emailed)

Card proof:
SNB-MyCards-redacted-OpenAI-x5-Cursor.png — personal rows (ZED, Tamimi) blacked;
keeps five OPENAI* CHATGPT CREDIT lines + one CURSOR USAGE AUG line.

DO NOT re-claim LHONW7ZI-0001–0019 (CFS 12678 / 12791).
